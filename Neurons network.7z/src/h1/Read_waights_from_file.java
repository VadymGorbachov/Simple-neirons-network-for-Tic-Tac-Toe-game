package h1;

import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class Read_waights_from_file {
	public static	int[] numArr;
	
	public static void read() {
		Data.swaights = "";
		try (FileReader reader = new FileReader("F:/Java/workspace/Neurons network/1.txt")) {
			int c;
			while ((c = reader.read()) != -1) {
				Data.swaights += (char) c;	}} 
		catch (IOException ex) {
			System.out.println(ex.getMessage());}
		    numArr = Arrays.stream(Data.swaights.split(" ")).mapToInt(Integer::parseInt).toArray();	
			Data.cell=0;
			for (int i=0; i<5; i++){
			  for(int j=0; j<9; j++){
				for(int k=0; k<9; k++){
				Data.waights [i][j][k]=Read_waights_from_file.numArr[Data.cell];	
				Data.cell++; }}}}}


