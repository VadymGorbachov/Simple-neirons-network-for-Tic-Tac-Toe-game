package h1;

public class Data {
	
	public static int i,j,k,choise,cell=0,max,num_max,step;
	public static int field [][]= {{0,0,0},{0,0,0},{0,0,0}};
	public static int field_besy []= {1,1,1,1,1,1,1,1,1};
	public static int [][][] waights = new int [6][9][9];
	public static int out [][] = {{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},};
	public static int adr_max [][] = {{1,1},{0,0},{0,0},{0,0},{0,0},{0,0}};
	public static String swaights;
	
}
