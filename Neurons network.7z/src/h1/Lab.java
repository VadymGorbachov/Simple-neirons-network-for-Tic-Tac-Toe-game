package h1;

public class Lab {
public static	void main(String args[]) {


	//GenerateStartWaightAndWriteToFile.write();

	Read_waights_from_file.read();
	//MethodInOut.print_weights();
	NeuronsNetwork.brain();
	//Save_weights_to_file.write();

}
}
