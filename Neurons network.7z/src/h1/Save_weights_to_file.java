package h1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;

public class Save_weights_to_file {
	static Formatter x;	
	
	public static void write() {
		
		Data.swaights="";
		for (Data.i=0; Data.i<5; Data.i++){
			for(Data.j=0; Data.j<9; Data.j++){
				Data.swaights+=(Data.waights [Data.i][Data.j]+" ");		}}
		try(FileWriter writer = new FileWriter("C:/Documents and Settings/Admin/workspace/Neurons network/1.txt", false))
       {writer.write(Data.swaights);
            writer.flush(); }
        catch(IOException ex){
            System.out.println(ex.getMessage());} } }
