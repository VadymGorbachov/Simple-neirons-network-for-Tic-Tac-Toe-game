package h1;
import java.io.FileWriter;
import java.io.IOException;


public class GenerateStartWaightAndWriteToFile {
	
	public static void  write(){
	for (Data.i=0; Data.i<5;Data.i++) {
		for (Data.j=0; Data.j<9;Data.j++){
			for (Data.k=0; Data.k<9;Data.k++){
				Data.waights[Data.i][Data.j][Data.k]=Data.k+1;
				
			}
		}
	}
	System.out.println();
	
	Data.swaights="";
	for (Data.i=0; Data.i<5; Data.i++){
		for(Data.j=0; Data.j<9; Data.j++){
			for (Data.k=0; Data.k<9;Data.k++){
			Data.swaights+=(Data.waights [Data.i][Data.j][Data.k]+" ");
			System.out.print(Data.waights [Data.i][Data.j][Data.k]);
		}
	}
	}
	System.out.println();
	
	
	try(FileWriter writer = new FileWriter("C:/Documents and Settings/Admin/workspace/Neurons network/1.txt", false))
    {        writer.write(Data.swaights);
        writer.flush(); }
    catch(IOException ex){ 
        System.out.println(ex.getMessage());    }
	
	
	
	
	}	
}