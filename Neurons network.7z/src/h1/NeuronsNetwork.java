package h1;

public  class NeuronsNetwork {

	public static void less_waights(){

		for(int i=0; i<5; i++){if (Data.adr_max[i][1]!=0) {Data.adr_max[i][1]--;}}
		for (int i=0; i<5; i++){
          if(Data.waights[i][Data.adr_max[i][1]][Data.adr_max[i][0]]!=0)
		  { Data.waights[i][Data.adr_max[i][1]][Data.adr_max[i][0]]--;}
			MethodInOut.print_weights();
			System.out.println("Victory Person!");


		}
		 System.exit(0);
	}
	public static void check_victory(){
		if (Data.field[0][0] == 2 & Data.field[0][1] == 2 & Data.field[0][2] == 2) {} else
		if (Data.field[1][0] == 2 & Data.field[1][1] == 2 & Data.field[1][2] == 2) {} else
		if (Data.field[2][0] == 2 & Data.field[2][1] == 2 & Data.field[2][2] == 2) {} else
		if (Data.field[0][0] == 2 & Data.field[1][1] == 2 & Data.field[2][2] == 2) {} else
		if (Data.field[2][0] == 2 & Data.field[1][1] == 2 & Data.field[0][2] == 2) {} else
		if (Data.field[0][0] == 2 & Data.field[1][0] == 2 & Data.field[2][0] == 2) {} else
		if (Data.field[0][1] == 2 & Data.field[1][1] == 2 & Data.field[2][1] == 2) {} else
		if (Data.field[0][2] == 2 & Data.field[1][2] == 2 & Data.field[2][2] == 2) {} else

		if (Data.field[0][0] == 3 & Data.field[0][1] == 3 & Data.field[0][2] == 3) {less_waights(); } else
		if (Data.field[1][0] == 3 & Data.field[1][1] == 3 & Data.field[1][2] == 3) {less_waights(); } else
		if (Data.field[2][0] == 3 & Data.field[2][1] == 3 & Data.field[2][2] == 3) {less_waights(); } else
		if (Data.field[0][0] == 3 & Data.field[1][1] == 3 & Data.field[2][2] == 3) {less_waights(); } else
		if (Data.field[2][0] == 3 & Data.field[1][1] == 3 & Data.field[0][2] == 3) {less_waights(); } else
		if (Data.field[0][0] == 3 & Data.field[1][0] == 3 & Data.field[2][0] == 3) {less_waights(); } else
		if (Data.field[0][1] == 3 & Data.field[1][1] == 3 & Data.field[2][1] == 3) {less_waights(); } else
		if (Data.field[0][2] == 3 & Data.field[1][2] == 3 & Data.field[2][2] == 3) {less_waights(); } }
	public static void mark_besy_cells_after_comp(){
		if (Data.adr_max[Data.step-1][0] == 0) {Data.field_besy[0]=0;}
		if (Data.adr_max[Data.step-1][0] == 1) {Data.field_besy[1]=0;}
		if (Data.adr_max[Data.step-1][0] == 2) {Data.field_besy[2]=0;}
		if (Data.adr_max[Data.step-1][0] == 3) {Data.field_besy[3]=0;}
		if (Data.adr_max[Data.step-1][0] == 4) {Data.field_besy[4]=0;}
		if (Data.adr_max[Data.step-1][0] == 5) {Data.field_besy[5]=0;}
		if (Data.adr_max[Data.step-1][0] == 6) {Data.field_besy[6]=0;}
		if (Data.adr_max[Data.step-1][0] == 7) {Data.field_besy[7]=0;}
		if (Data.adr_max[Data.step-1][0] == 8) {Data.field_besy[8]=0;}
	}
	public static void mark_besy_cells_after_me(){
		if (Data.choise == 1) {Data.field_besy[0]=0;}
		if (Data.choise == 2) {Data.field_besy[1]=0;}
		if (Data.choise == 3) {Data.field_besy[2]=0;}
		if (Data.choise == 4) {Data.field_besy[3]=0;}
		if (Data.choise == 5) {Data.field_besy[4]=0;}
		if (Data.choise == 6) {Data.field_besy[5]=0;}
		if (Data.choise == 7) {Data.field_besy[6]=0;}
		if (Data.choise == 8) {Data.field_besy[7]=0;}
		if (Data.choise == 9) {Data.field_besy[8]=0;}
	}
	public static void find_max_waight() {
		System.out.println(Data.step+"Data.step");
		//System.out.println("Victory Person!");
		//System.out.println("Victory Person!");
		//System.out.println("Victory Person!");

 		Data.max=Data.waights[Data.step-1][Data.adr_max[Data.step-1][1]][0]*Data.field_besy[0];
		Data.adr_max[Data.step][1]=Data.adr_max[Data.step-1][0]; Data.adr_max[Data.step][0]=Data.adr_max[Data.step-1][1];

		for (int i = 1; i<9; i++) {

			if (Data.max<Data.waights[Data.step-1][Data.adr_max[Data.step-1][1]-1][i]*Data.field_besy[i]) {
				Data.max=Data.waights[Data.step-1][Data.adr_max[Data.step-1][1]-1][i];
				Data.adr_max[Data.step][0]=i;
				Data.adr_max[Data.step][1]=Data.adr_max[Data.step-1][0];
			}}}
/*	public static void find_max_waight() {
		Data.max=Data.waights[Data.step-1][Data.choise-1][0]*Data.field_besy[0];
		Data.adr_max[Data.step-1][0]=0; Data.adr_max[Data.step-1][1]=Data.choise;
		for (int i = 1; i<9; i++) {
			if (Data.max<Data.waights[Data.step-1][Data.choise-1][i]*Data.field_besy[i]) {
				Data.max=Data.waights[Data.step-1][Data.choise-1][i];	Data.adr_max[Data.step-1][0]=i;
			}}} */
	public static void step_brain_comp(){
		if (Data.adr_max[Data.step-1][0] == 0 & Data.field_besy[0]!=0) {Data.field[0][0]=2;}
		if (Data.adr_max[Data.step-1][0] == 1 & Data.field_besy[1]!=0) {Data.field[0][1]=2;}
		if (Data.adr_max[Data.step-1][0] == 2 & Data.field_besy[2]!=0) {Data.field[0][2]=2;}
		if (Data.adr_max[Data.step-1][0] == 3 & Data.field_besy[3]!=0) {Data.field[1][0]=2;}
		if (Data.adr_max[Data.step-1][0] == 4 & Data.field_besy[4]!=0) {Data.field[1][1]=2;}
		if (Data.adr_max[Data.step-1][0] == 5 & Data.field_besy[5]!=0) {Data.field[1][2]=2;}
		if (Data.adr_max[Data.step-1][0] == 6 & Data.field_besy[6]!=0) {Data.field[2][0]=2;}
		if (Data.adr_max[Data.step-1][0] == 7 & Data.field_besy[7]!=0) {Data.field[2][1]=2;}
		if (Data.adr_max[Data.step-1][0] == 8 & Data.field_besy[8]!=0) {Data.field[2][2]=2;}	}
	public static void step_brain_I(){
		if (Data.choise == 1) {Data.field[0][0]=3;}
		if (Data.choise == 2) {Data.field[0][1]=3;}
		if (Data.choise == 3) {Data.field[0][2]=3;}
		if (Data.choise == 4) {Data.field[1][0]=3;}
		if (Data.choise == 5) {Data.field[1][1]=3;}
		if (Data.choise == 6) {Data.field[1][2]=3;}
		if (Data.choise == 7) {Data.field[2][0]=3;}
		if (Data.choise == 8) {Data.field[2][1]=3;}
		if (Data.choise == 9) {Data.field[2][2]=3;}
	}
    public static void brain() {

	Data.step = 1;
	MethodInOut.print_field();
	MethodInOut.read_choise();
	step_brain_I();
	mark_besy_cells_after_me();
	find_max_waight();
	step_brain_comp();
	mark_besy_cells_after_comp();
	MethodInOut.print_field();

	Data.step = 2;
	MethodInOut.print_field();
	MethodInOut.read_choise();
	step_brain_I();
	mark_besy_cells_after_me();
	find_max_waight();
	step_brain_comp();
	mark_besy_cells_after_comp();
	MethodInOut.print_field();

	Data.step = 3;
	MethodInOut.print_field();
	MethodInOut.read_choise();
	step_brain_I();
	mark_besy_cells_after_me();
	find_max_waight();
	step_brain_comp();
	mark_besy_cells_after_comp();
	MethodInOut.print_field();
	check_victory();

	Data.step = 4;
	MethodInOut.print_field();
	MethodInOut.read_choise();
	step_brain_I();
	mark_besy_cells_after_me();
	find_max_waight();
	step_brain_comp();
	mark_besy_cells_after_comp();
	MethodInOut.print_field();
	check_victory();

	Data.step = 5;
	MethodInOut.print_field();
	MethodInOut.read_choise();
	step_brain_I();
	mark_besy_cells_after_me();
	find_max_waight();
	step_brain_comp();
	mark_besy_cells_after_comp();
	MethodInOut.print_field();
	check_victory();

}
}
