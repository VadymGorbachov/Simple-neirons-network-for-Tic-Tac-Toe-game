package h1;
import java.util.Scanner;

public class MethodInOut {
	
    public static void read_choise(){	
	System.out.println();
    Scanner in = new Scanner(System.in);
    Data.choise = in.nextInt(); }
	public static void print_example(){
		System.out.println("Example");
		int k=0;
		for (int i = 1; i < 4; i++){				
		for (int j = 1; j < 4; j++){
		k++;	System.out.print(k+"  ");}
		System.out.println();}}
	public static void print_weights(){
		Data.cell=0;
		for (Data.i=0; Data.i<5; Data.i++){System.out.println();
		for(Data.j=0; Data.j<9; Data.j++){System.out.print(" ");
			for(Data.k=0; Data.k<9; Data.k++){
			System.out.print(Data.waights [Data.i][Data.j][Data.k]);
			Data.cell++; }}} System.out.println();}
	public static void print_field (){
		for (int i = 0; i < 3; i++){System.out.println();
			for (int j = 0; j < 3; j++){
				if (Data.field[i][j]==3){System.out.print("[x] ");}
				if (Data.field[i][j]==2){System.out.print("[o] ");}
				if (Data.field[i][j]==0){System.out.print("[ ] ");} }}System.out.println();}
				
}
